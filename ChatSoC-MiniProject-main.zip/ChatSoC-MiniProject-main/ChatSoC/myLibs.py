import os
import openai as myAi
import pandas as pd
from PIL import Image as img
import qrcode as qr 
import pyttsx3
import datetime as dt
import wikipedia as wp
import webbrowser as wb
import speech_recognition as sr
from dotenv import load_dotenv as env
import json
from io import BytesIO
import requests
from pytube import YouTube as yt
import cv2
import pyzbar.pyzbar as pyzbar 
import csv 
