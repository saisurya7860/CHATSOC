# ChatSoC-MiniProject
AI-Powered chatbot with various features
